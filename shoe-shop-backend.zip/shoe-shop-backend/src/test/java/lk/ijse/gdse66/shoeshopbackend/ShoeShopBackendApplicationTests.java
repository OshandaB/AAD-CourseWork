package lk.ijse.gdse66.shoeshopbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoeShopBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
